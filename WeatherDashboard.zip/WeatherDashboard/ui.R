#
# This is the user-interface definition of a Shiny web application. You can
# run the application by clicking 'Run App' above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#

library(shiny)
library(shinydashboard)

ui <- fluidPage(dashboardPage(
    dashboardHeader(title = "Weather Data Analysis"),
    dashboardSidebar(
        sidebarMenu(
            menuItem("Introduction and Research Problem", tabName = "Introduction"),
            menuItem("Exploratory Data Analysis", tabName = "eda"),
            menuItem("Linear Regression", tabName = "lr"),
            menuItem("Decision Trees", tabName = "dt"),
            menuItem("Neural Networks", tabName = "nn"),
            menuItem("Trend Analysis", tabName = "ta"),
            menuItem("Results and Inferences", tabName = "ri")
        )
    ),
    dashboardBody(
        tabItems(
            tabItem(tabName = "Introduction",
                    fluidRow(
                        box(
                            title = "Introduction",  status = "primary", solidHeader = TRUE,
                            tags$div(
                                tags$p("The detection and estimation of trends and associated statistical and physical significance are important aspects of climate research. Especially in the field of Agriculture industry. Trend analysis provides a concrete base in efficiently managing resources in crop cultivation and agriculture."),
                                tags$br(),
                                tags$p("Here in this study, we are focusing on trend detection and analysis of Maximum temperature in the weather dataset. We have chosen max temperature as our primary target attribute because, Maximum Temperature is an important factor in determining the rate of evaporation of water, hydroelectric power generation, domestic and industrial water supply and Agriculture. The trend analysis of temperature (Arora et al., 2005; Karanurun and Kara,
                                      2011; Meshram et al., 2018) and other climatic variables on different spatial scales will help in the construction of future climate scenarios (Panda and Sahu, 2019).
                                      "),
                                tags$br(),
                                tags$p("In this study, two non-parametric, statistical methods of trend detection namely, Mann Kendall Method and Sen \' s Slope Method are used. Both the methods have been implemented twice. Firstly, on geographical station location and secondly on Month. The
                                    nonparametric tests are more suitable for non-normally distributed, censored data, including missing values, which are frequently encountered in hydrological time series (Hirsch & Slack, 1984).
                                    ")
                            ),
                            
                            
                        ),
                        box(
                            title = "Research Problem", status = "primary", solidHeader = TRUE,
                            tags$ol(
                                tags$li("To find the trend with values in 95% Confidence Interval."),
                                tags$li("To detect and analyze trend with station wise approach."),
                                tags$li("To detect and analyze trend with Month wise approach."),
                                tags$li("To provide a combined analysis based on both the approaches."),
                            ),
                        
                        )
                    )
            ),
            tabItem(tabName = "eda",
                    tags$h1("Exploratory Data Analysis"),
                    fluidRow(
                         tabBox(
                            id = "tabset1", 
                            tabPanel("Min Temp", img(src='bplotMinTemp.png',height="250px", width="50%" )),
                            tabPanel("Temp Dry Bulb", img(src='bplotDryBulb.png',height="250px", width="50%" )),
                            tabPanel("Temp Wet Bulb", img(src='bplotWetBulb.png',height="250px", width="50%" )),
                            tabPanel("Relative Humidity", img(src='bplotRelativeHumidity.png',height="250px", width="50%" )),
                            tabPanel("Inst. Wind Speed", img(src='bplotInstWindSpeed.png',height="250px", width="50%" )),
                            tabPanel("Pan Evaporation", img(src='bplotPanEvap.png',height="250px", width="50%" )),
                            tabPanel("Temp Pan Water", img(src='BplotTempPanWater.png',height="250px", width="50%" )),
                            tabPanel("Max Temp", img(src='bplotMaxTemp.png', height="250px", width="50%"))
                            
                        ),
                        box(title = "Outlier and Missing values removal", status = "primary" , solidHeader = TRUE,
                            tags$ol(
                                tags$li("From the first plot, we can infer that for Min.Temperature the Median is around 22 degrees Celsius. On the other hand, for both Max.Temperature and Temp.Dry Bulb the median is around 33 degrees Celsius and 28 degrees Celsius respectively. "),
                                tags$li("If we talk about the data, then from all the 3 boxes for Min temperature the box looks more compressed(data values lie between the range 20-27) as compared to the other two variables"),
                                tags$li("For each variable, there are outliers that are present outside the range of the plot."),
                                tags$li("The second plot is of 3 different variables from the dataset. In the plot, it???s clear that the median is varying for all the three given variables. For Temp.Wet Bulb is around 24 degrees Celsius, whereas for Relative Humidity it is around 70-72 and 2.6-2.8 for Inst.Wind.Speed respectively."),
                                tags$li("In the last plot, we have two variables, Pan Evaporation and Pan Water. The median for the first is around 2.7 and 27 for the later.")
                            ),
                            tags$br(),
                            tags$p("* The temperatures are measured in degrees celsius.")
                             ),
                        
                    ),
                    tags$br(),
                    tags$p("The figure  shows correlation matrix between different variables"),
                    #tags$br(),
                    fluidRow(box(title = "Correlation Matrix", status = "primary", tags$img(src='correlation.png',height="50%", width="70%")),
                             box(title = "Correlation Matrix Inference", status = "primary", solidHeader = TRUE,
                                 tags$p("From the correlation plot it is evident that there is a positive correlation between:"),
                                 tags$ol(
                                     tags$li("Max. Temperature and Temp.Dry Bulb"),
                                     tags$li("Temp.Dry bulb and Temp.Wet Bulb"),
                                     tags$li("Temp.Wet Bulb and Min.Temperature")
                                 ),
                                 tags$p("There is a negative correlation between the following variables:"),
                                 tags$ol(
                                     tags$li("Relative Humidity and Max.temp"),
                                     tags$li("Relative Humidity and Temp.dry bulb"),
                                     tags$li("Relative Humidity and Pan Evaporation"),
                                 ),
                                 tags$br(),
                                 tags$p("We used IQR method to remove outliers and mean values to impute numerical missing values. To deal with missing categorical values we used KNN method with value of K equals to sqrt(number of distinct values) .")),
                             #tags$br(),
                             )
),
            tabItem(tabName = "lr",
                    fluidRow(
                        box(title="Linear Regression Results", status ="primary", solidHeader =TRUE, tags$img(src='lrresults.png',height="250px", width="70%")),
                        box(title = "Results",status = "primary", solidHeader = TRUE, tags$p("Results:",tags$br(),"Residuals:",tags$br(),"Min:-11.4674 , 1Q:-1.6881,Median:-0.1421, 3Q:1.4923, Max:11.3346 ", tags$br(),
                                                                                             "Residual standard error: 2.601 on 53668 degrees of freedom", tags$br(),
                                                                                             "Multiple R-squared:  0.4902,	Adjusted R-squared:   0.49", tags$br(),
                                                                                             "F-statistic:  2064 on 25 and 53668 DF,  p-value: < 2.2e-16"
                                                                                             )) 
                         
                    ),
                    fluidRow(
                        box(title = "Inferences",status = "warning", solidHeader = TRUE, tags$p("The larger the R-squared, the better the regression model fits your observations. As it is evident the R-squared values of the model is less than 1 and hence it is not fitting well our observations.")) 
                    )
            ),
            tabItem(tabName = "dt",
                    fluidRow(
                        box(title = "Global Decision Tree", status = "primary", solidHeader = TRUE, tags$img(src='GlobalRegressionTree.png',height="50%", width="70%")),
                        box(title = "Inferences and results from the Global Decision Tree", status = "primary", solidHeader = TRUE,
                            tags$p("The final tree is formed using Temp.Dry Bulb, Pan Evaporation, and Min. temperature.", tags$br() ," Where Temp.Dry Bulb is selected as the root node by the model. If the temp is less than 31 then 77% of the training data is going to the left of the root node and also Pan evaporation is < 2.4 and Temp.dry bulb < 29 then at the leaf node 33% of the data will have Max temperature= 30 degrees.
                                   ",tags$br(),"On the other hand, if the temp is more than 31 then 23% of the training data is going to the right of the root node. And at the leaf node if Temp Dry bulb < 34 then, 14% of the data will have Max temperature = 35 degrees.
                                   "),
                            tags$br(),
                            strong("RMSE of the model: 2.598"))
                    ),
                    fluidRow(
                        tabBox(
                        id = "StationWise", 
                        tabPanel("Amli", img(src='Amli.png',height="50%", width="50%" )),
                        tabPanel("Chopadvav", img(src='Chopadvav.png',height="50%", width="50%" )),
                        tabPanel("Godsamba", img(src='Godsamba.png',height="50%", width="50%" )),
                        tabPanel("Kakrapar", img(src='Kakrapar.png',height="50%", width="50%" )),
                        tabPanel("Olpad", img(src='Olpad.png',height="50%", width="50%" )),
                        tabPanel("Rander", img(src='Rander.png',height="50%", width="50%" )),
                        tabPanel("Ukai", img(src='Ukai.png',height="50%", width="50%" ))
                        
                    ),
                        box(title = "Stationwise Decision Tree Implementation", status = "primary", solidHeader = TRUE,
                            tags$p("Out of all the variables, the main variation that I observed was for Relative Humidity compared with Max. Temperature.",tags$br(),
                                   tags$ol("Max temperature data distribution:",
                                       tags$li("For Station codes Chopadvav and Ukai we are observing a bimodal histogram for the data values of Max. temperature."),
                                       tags$li("For other Stations, the distribution of the data was more likely to be Normal distribution.")
                                   )),
                            strong("Cumulative RMSE of all the Station code models:  2.435")
                            )
                    
                    ),
                    fluidRow(
                        box(title = "Inferences",status = "warning", solidHeader = TRUE, tags$p("After running both Global and Local models the RMSE evaluation came out to be almost similar. So, In my suggestion for future weather-related predictions, we can use the Global model"))
                    )
            ),
            tabItem(tabName = "nn",
                    h2("Neural Networks clicked")
            ),
            tabItem(tabName = "ta",
                    fluidRow(
                        box(
                            title = "Methodology", background = "green", solidHeader = TRUE,
                        )
                    ),
                    fluidRow( style = "width: 100%; height: 100%;",
                            box(title = "Methodology",status = "primary", solidHeader = TRUE,div( tags$p(strong("Methodologies"),tags$br(),"For both the methodologies,Mann Kendall Method and Sen???s Slope Method, following hypotheses are used.",tags$br(),
                                strong("Null Hypothesis H0"),"The hypothesis being tested. Usually a hypothesis of no change or no difference or no trend",
                                tags$br(),strong("Alternate Hypothesis H1"),"Some departure from Ho that might be expected. The departure that one expects to see which means the trend exists. ")))
                     ),
                    fluidRow(
                        box(title = "Mann Kendall Method",status = "primary", solidHeader = TRUE, 
                            tags$p("The M - K test is a statistical nonparametric test widely used for trend analysis in climatological and hydrological time series data. The test was suggested by Mann (1945) and has been extensively used with environmental time series. There are two advantages to use this test. First, it is a nonparametric test and does not require the data to be normally distributed. Second, the test has low sensitivity to abrupt breaks due to inhomogeneous time series. According to this test, the null hypothesis H0 assumes that there is no trend (the data is independent and randomly ordered). This is tested against the alternative hypothesis H1, which assumes that there is trend. The M - K statistic is computed as follows:",
                                   tags$br(),
                                   img(src='eqn1.png',height="70px", width="200px" ),
                                   tags$br(),
                                   "The trend test is applied to a time series Xk, which is ranked from k = 1,2,3 ... n - 1 , which is ranked from j = I + 1,i + 2,i + 3...n. Each of the data points xj is taken as a reference point,",
                                   tags$br(),
                                   img(src='eqn2.png',height="70px", width="200px" ),
                                   tags$br(),
                                   "This test has been calculated using",strong("Kendall")," package in R.")),
                        box(title = "Sen \' s Slope Method",status = "primary", solidHeader = TRUE, 
                            tags$p("It is distribution free and not affected by seasonal fluctuations. This technique involves in arranging the collected data in the rank wise and scatter plotting and then calculating the median of those data. Based on that median of the data type of trend is decided.",
                                   tags$br(),
                                   "This test computes both the slope (i.e. linear rate of change) and confidence levels according to Sen's method. First, a set of linear slopes is calculated as follows:",
                                   tags$br(),
                                   img(src='eqn3.png',height="70px", width="200px" ),
                                   tags$br(),
                                   "for (1 <= i < j <= n), where d is the slope, x denotes the variable, n is the number of data, and i, j are indices.
                                    Sen's slope is then calculated as the median from all slopes:",
                                   tags$br(),
                                   img(src='eqn4.png',height="30px", width="200px" ),
                                   tags$br(),
                                   "This function also computes the upper and lower confidence limits for sens slope. This test has been calculated using",strong("Trend")," package in R."
                                   ))
                    ),
                    fluidRow(
                        box(
                            title = "State wise analysis", background = "green", solidHeader = TRUE,
                        )
                    ),
                    fluidRow(
                        
                        tabBox(
                            id = "StationWise", 
                            tabPanel("Amli", img(src='Saamli.png',height="50%", width="50%" )),
                            tabPanel("Chopadvav", img(src='sachopadvav.png',height="50%", width="50%" )),
                            tabPanel("Godsamba", img(src='saghodsamba.png',height="50%", width="50%" )),
                            tabPanel("Kakrapar", img(src='sakakrapara.png',height="50%", width="50%" )),
                            tabPanel("Olpad", img(src='saolpad.png',height="50%", width="50%" )),
                            tabPanel("Rander", img(src='sarander.png',height="50%", width="50%" )),
                            tabPanel("Ukai", img(src='saukai.png',height="50%", width="50%" ))
                            
                        ),
                        box(title = "Station Wise Analysis",status = "primary", solidHeader = TRUE, tags$p("In station wise analysis, the values of maximum temperature have been grouped together along the Year and Month and mean value is summarized for each of the seven stations. ",
                                                                                                           tags$br(),
                                                                                                           "The graphs show the decomposition of maximum temperature across the years for the data, seasonal, trend and remainder for all the stations. These graphs show the data distributions which are too random to detect the trends. Hence the statistical methods."))
                    ),
                    fluidRow(
                        box(title = "Mann Kendall for Station", status = "primary", tags$img(src='MKStation.png',height="50%", width="70%")),
                        box(title = "Station wise results for Mann Kendall", status = "primary", solidHeader = TRUE
                            ,tags$p("The figure contains results for Mann - Kendall method.",
                            tags$br(),
                            "Stations Godsamba and Ukai have shown a significantly Increasing trend for Maximum temperature whereas Kakrapar and Amli have shown a significantly decreasing trend."
                        ))
                    ),
                    fluidRow(
                        box(title = "Sen \'s slope state wise", status = "primary", tags$img(src='MKStationwise.png',height="50%", width="70%")),
                        box(title = "Station wise results for Sen \'s slope", status = "primary", solidHeader = TRUE
                            ,tags$p("The values of Sen's slope and their respective 95% confidence Intervals are shown in the table.",tags$br(),
                                    "The 95% Confidence Interval reflects the range of sen's slope values for which the trend exists I.e. the alternate hypothesis is considered.")
                            )
                    ),
                fluidRow(
                    box(
                    title = "Month wise analysis", background = "green", solidHeader = TRUE,
                )),
                fluidRow(
                    box(title = "Month wise analysis ", status = "primary", tags$img(src='mwanalysis.png',height="50%", width="70%")),
                    box(title = "Month wise analysis", status = "primary", solidHeader = TRUE
                        ,tags$p("In month wise analysis, the values of maximum temperature have been grouped together along the Month and Stations and mean value is summarized for each month. ",tags$br(),
                                "The figure shows the Mean maximum temperature for January for the entire data from 1999 to 2014 for above mentioned stations in that order. Black line represents the plot of the data and blue line represents the fitted line for the data.")
                    )
                ),
                fluidRow(
                    box(title = "Mann Kendall month wise", status = "primary", tags$img(src='mkmonthwise.png',height="50%", width="70%")),
                    box(title = "Station wise results for Mann Kendall", status = "primary", solidHeader = TRUE
                        ,tags$p("As per the study and the graphs shown in the Figure, January, March, April, May and June have a decreasing trend and July, August and September have a little significant increasing trend over the years"
                            ))
                ),
                fluidRow(
                    box(title = "Sen \'s slope month wise", status = "primary", tags$img(src='ssmonthwise.png',height="50%", width="70%")),
                    box(title = "Station wise results for Sen \'s slope", status = "primary", solidHeader = TRUE
                        ,tags$p("The values of Sen's slope and their respective 95% confidence Intervals are shown in the figure.")
                    )
                ),
                
                
                )
            ,
            tabItem(tabName = "ri",
            fluidRow(
                        box(
                            title = "Conclusion",  status = "primary", solidHeader = TRUE,
                            tags$div(
                                tags$p("By combining both the analytical approaches, it can be insinuated that Regions around Kakrapar and Amli in the months of January, March, April, May and June can have very significant drop in the Maximum temperature values and on the other hand, Godsamba and Ukai can have very significant rise in the Maximum Temperature values in the months of July, August and September. This conclusion is based on the fact that the trends detected for the above mentioned regions and Months are either increasing or decreasing for both the regions and months values. The concerning industries can be helped with this analysis to plan their resources efficiently. Both the methods have detected the trends and Sen???s Slope values come under the confidence interval bracket which strengthens our hypothesis."),
                                tags$br(),
                                tags$p("Both the non-parametric approaches don???t take into account the type of data distribution in the series. One of the problems in detecting and interpreting trends in hydrologic data is the Confounding effect of serial dependence. When it comes to the weather data, there are a lot of factors that are needed to be taken into consideration so as to provide a prominent analysis. For example, the number of trees in the area can severely affect the value of maximum temperature.")
                            ),
                            
                            
                        ),
                        box(
                            title = "References", status = "primary", solidHeader = TRUE,
                            tags$ol(
                                tags$li("Arora, M., Goel, N.K. and Singh, P. (2005) Evaluation of temperature trends over India. Hydrological Sciences Journal, 50, 81???93."),
                                tags$li("Arpita Panda, Netrananda Sahu (2019) Trend analysis of rainfall and temperature pattern in Kalahandi, Bolangir and Koraput districts of Odisha, India, Atmospheric Science Letters."),
                                tags$li("Robert M. Hirsch, James R. Slack (1984) A non parametric trend test for seasonal data with serial dependence. Water Resources Research, Vol. 20, Issue 6, 727-732"),
                                tags$li("Praveen Rathod (2014), A comparative study of methods used for rainfall trend analysis. Seminar 2014, M.Tech WRE.")
                            )
                        )
                    )
            )
            
        )
    )
)
)


